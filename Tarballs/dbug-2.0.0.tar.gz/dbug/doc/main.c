#ifdef DBUG_OFF						   /* We are testing dbug */
#undef DBUG_OFF
#endif
