/* Declarate _sanity() if not declared in main program */
